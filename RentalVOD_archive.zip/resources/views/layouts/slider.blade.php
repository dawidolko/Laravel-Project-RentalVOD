<!-- Fonts & Icons -->
<link href="https://fonts.googleapis.com/css2?family=Advent+Pro:wght@100;200;300;400;500;600;700&family=Cabin:ital,wght@0,400;0,500;0,600;0,700;1,400;1,500;1,600;1,700&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
{{-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>  // zakomentowane, ponieważ nie wolno używać jquery --}} 
<script src="https://kit.fontawesome.com/828184f452.js" crossorigin="anonymous"></script>
<!-- JS -->
<script src="{{ asset('js/slide.js') }}"></script>
<!-- CSS -->
<link rel="stylesheet" href="{{ asset('css/slide.css') }}">    
<!-- Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Advent+Pro:wght@100;200;300;400;500;600;700&family=Cabin:ital,wght@0,400;0,500;0,600;0,700;1,400;1,500;1,600;1,700&display=swap" rel="stylesheet">
<!-- CSS -->
<link rel="stylesheet" href="{{ asset('css/strip.css') }}">    
<!-- Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Advent+Pro:wght@100;200;300;400;500;600;700&family=Cabin:ital,wght@0,400;0,500;0,600;0,700;1,400;1,500;1,600;1,700&display=swap" rel="stylesheet">
<!-- JS -->
<script src="{{ asset('js/topfive.js') }}"></script>
<!-- CSS -->
<link rel="stylesheet" href="{{ asset('css/topfive.css') }}">