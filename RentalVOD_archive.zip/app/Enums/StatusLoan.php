<?php

namespace App\Enums;

use BenSampo\Enum\Enum;

final class StatusLoan extends Enum
{
    const WYNAJEM = 'wynajem';
    const ZWROCONE = 'zwrócone';
}
