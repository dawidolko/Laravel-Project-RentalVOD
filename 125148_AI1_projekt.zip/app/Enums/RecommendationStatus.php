<?php

namespace App\Enums;

enum RecommendationStatus: string
{
    case Recommended = 'polecony';
    case Watched = 'ogladane';
}
